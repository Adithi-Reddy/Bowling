var express = require('express');

var app = express();
var fs = require("fs");

app.set('port', process.env.PORT || 3000);

app.get('/', function(req, res){
        res.type('text/plain');
        res.send('Meadowlark Travel');
});
app.get('/about', function(req, res){
        res.type('text/plain');
        res.send('About Meadowlark Travel');
});
app.get('/index.htm', function (req, res) {
   res.sendFile( __dirname + "/" + "AddUser.html" );
})
app.get('/listUserScores', function (req, res) {
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
       console.log( data );
       res.end( data );
   });
});

app.get('/addUser', function (req, res) {
   // First read existing users.
   var r=req
   console.log( req.query.id );
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
       data = JSON.parse( data );
       data[req.query.id]=('{name: '+req.query.name+', id: '+req.query.id+'}'
);
       console.log( data );
       res.end( JSON.stringify(data));
	   fs.writeFile(__dirname + "/" + "users.json", JSON.stringify(data), function (err) {
  if (err) return console.log(err);
  console.log('Hello World > helloworld.txt');
});
   });
});
app.get('/:id', function (req, res) {
   // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
       users = JSON.parse( data );
       var user = users[req.params.id] 
       console.log( user );
       res.end( JSON.stringify(user));
   });
});
app.get('/deleteUser/:id', function (req, res) {

   // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
       data = JSON.parse( data );
       delete data[id];
       
       console.log( data );
       res.end( JSON.stringify(data));
   });
});

// custom 404 page
app.use(function(req, res){
        res.type('text/plain');
        res.status(404);
        res.send('404 - Not Found');
});

// custom 500 page
app.use(function(err, req, res, next){
        console.error(err.stack);
        res.type('text/plain');
        res.status(500);
        res.send('500 - Server Error');
});

app.listen(app.get('port'), function(){
  console.log( 'Express started on http://localhost:' +
    app.get('port') + '; press Ctrl-C to terminate.' );
});
