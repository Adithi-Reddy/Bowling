describe('The Bowling Game', function(){
var game;
	beforeEach(function(){
		game= new BowlingGame();
	});
	it('can parse score XXXXXXXXXXXX', function(){
		game.parseScore('XXXXXXXXXXXX');
		expect(game.score()).toBe(300);
	});
	it('can parse score 90909090909090909090', function(){
		game.parseScore('90909090909090909090');
		expect(game.score()).toBe(90);
	});
	it('can parse score 5/5/5/5/5/5/5/5/5/5/5', function(){
		game.parseScore('5/5/5/5/5/5/5/5/5/5/5');
		expect(game.score()).toBe(150);
	});
	it('can parse score X7/729/XXX236/7/3', function(){
		game.parseScore('X7/729/XXX236/7/3');
		expect(game.score()).toBe(168);
	});
	it('can parse score 00000000000000000000', function(){
		game.parseScore('00000000000000000000');
		expect(game.score()).toBe(0);
	});
	it('can parse score 01273/X5/7/345400X70', function(){
		game.parseScore('01273/X5/7/345400X70');
		expect(game.score()).toBe(113);
	});
	it('can parse score X7/90X088/06XXX81', function(){
		game.parseScore('X7/90X088/06XXX81');
		expect(game.score()).toBe(167);
	});
	it('can parse score X7/90X088/06XXX81', function(){
		game.parseScore('XXXXXXXXXXXX');
		expect(game.score()).toBe(300);
	});
	it('can create game', function(){
		var game = new BowlingGame();
	});
	it('can role gutter game', function(){
		rollMany(0,20);
		expect(game.score()).toBe(0);
	});
	it('can role all ones ', function(){
		rollMany(1,20);
		expect(game.score()).toBe(20);
	});
	it('can role a spare ', function(){
		game.roll(5);
		game.roll('/');
		game.roll(3);
		rollMany(0,17);
		expect(game.score()).toBe(16);
	});
	it('can role a strike ', function(){
		game.roll('X');//game.roll(0);
		game.roll(4);
		game.roll(3);
		rollMany(0,16);
		expect(game.score()).toBe(24);
	});
	it('can role all strikes ', function(){
		
		rollMany('X',12);
		expect(game.score()).toBe(300);
	});
	it('can role a ones ', function(){
		rollMany(1,20);
		expect(game.score()).toBe(20);
	});
	
	//error case
	//unknown exception case
	var rollMany = function(pins,rolls){
	for (var i=0;i<rolls;i++){
			game.roll(pins);
		}
	};
});