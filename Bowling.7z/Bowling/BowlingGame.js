var BowlingGame = function(){
	this.rolls=[];
};
BowlingGame.prototype.parseScore = function(fullScore){
var size = fullScore.length;
for (var i =0;i <size;i++){
	var pins = fullScore.charAt(i);
	if(pins=='X'){this.rolls.push(10);}
	else if(pins!='/'){this.rolls.push(Number(pins));}
	else{this.rolls.push(pins);}
}
	
};
BowlingGame.prototype.roll = function(pins){
if(pins=='X'){this.rolls.push(10);}
else{this.rolls.push(pins);}
	
};
BowlingGame.prototype.score = function(){
	var result =0;
	var index =0;
	for (var set=0;set<10;set++){
		if(this.rolls[index]==10){ //strike
			if(this.rolls[index+2]!='/'){
			result+=10+this.rolls[index+1]+this.rolls[index+2];}
			else{
			result+=20;
			}
			index--;
		}else if(this.rolls[index+1] =='/'){ //spare
			result+=10+this.rolls[index+2];
		}else{ //neither spare nor strike 
			result+=this.rolls[index]+this.rolls[index+1];
			}
			index+=2;
		}
	return result;
	};